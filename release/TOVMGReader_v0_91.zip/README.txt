===========================================
The Owl VMG Reader - v.0.91 (14 july 2012)

Coded by Louisbob - www.owl-black.net
manzhack@gmail.com
===========================================

This software is not open source yet. You can ask me for the code source.
You are not allowed to modify it or change its behaviour without permission.

HOW-TO on my website

EnJoY!!

CHANGELOG:

v. 0.91 (14/07/2012) - Update for Nimay request: exporting to android.

-*NEW*: In the export menu, you can now choose if you want to merge the date with the time. This trick allows
importing output CSV file on android device, using SMS Importer app. (http://goo.gl/mrZ1F)
-*FIX*: image into "About" menu doesn't show correctly.
-*FIX*: "export" menu interface has been totally reworked, allowing addding features in the future.

v. 0.9 (12/07/2012) - I dedicate this release to Ranma, my first and generous contributor! I warmly thanks him!

-*NEW*: The application is now multi-platform. It has been completely rewritten in JAVA language.
It took me 5 months of hard work.
-*NEW*: User interface has been totally rethink: easier to use, and better view.
-*NEW*: All messages are sorted by date
-*NEW*: Now, there is an inbox/outbox differentiation to make SMS stream like iPhone conversation!
-*FIX*: Accent characters are also modified in the .CSV output file
-*FIX*: Improved the general algorithm

This is my most important update for the software, please donate if you like it, or send me a message 
if you encounter bugs.


v. 0.8 (12/06/2012) - Thanks to Den for his/her bug report!

-*FIX*: VMG text was not properly recognized by the algorithm for VMGs
	generated with a Samsung Duos GT E2652w.

v. 0.7 (27/04/2012) - Thanks to Daniel for his bug report!

-*FIX*: There were some vmgs with bad-formatted dates, that generate
 	a System.IndexOutOfRangeException. Now, the date is well recognized.

-*FIX*: The software didn't find a rare beacon named "TEXT:", in a odd version 
	of VMG files. The text didn't show up correctly. Now, it's fixed.


v. 0.6 (23/01/2012) - Thanks to harshit and Benjamin V. for their bug reports!

-Before, you can export only 400 sms. Now,
you can export up to 10000 sms!

*FIX: "Merg'em all" button and "Process" were not available using classical merging technic.
Now, there will be available when you select all your VMGs. 